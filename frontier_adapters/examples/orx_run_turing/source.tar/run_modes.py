"""Exact-rational linear-stability scan of ONE declared two-species reaction-diffusion model.

Model (declared, not measured): u_t = a u + b v + Du u_xx, v_t = c u + d v + Dv v_xx on [0, L],
zero-flux boundaries, J = [[1,-2],[2,-3]], Du = 1, Dv = 10.  L = (p/s) * pi, so the Neumann mode
numbers are q_n = (n*pi/L)^2 = (n*s/p)^2, a RATIONAL number: no floating point, no randomness, no
external input.  A mode is linearly stable iff trace < 0 and determinant > 0 (Routh-Hurwitz for 2x2).
It does NOT touch the PDE dynamics, nonlinear patterning, or any measurement.
"""
import json, hashlib
from fractions import Fraction as F

a, b, c, d, Du, Dv = F(1), F(-2), F(2), F(-3), F(1), F(10)
N = 100                      # modes n = 0..N; the tail beyond q >= S/(Du*Dv) is stable (algebraic argument, not re-proved here)
DOMAINS = {"pi": (1, 1), "3pi/2": (3, 2), "2pi": (2, 1), "5pi/2": (5, 2), "3pi": (3, 1), "4pi": (4, 1)}  # L = p/s * pi given as (p, s)

def mode(q):
    tr = (a + d) - (Du + Dv) * q
    det = (Du * q - a) * (Dv * q - d) - b * c
    return tr, det

out = {"model": {"J": [[str(a), str(b)], [str(c), str(d)]], "Du": str(Du), "Dv": str(Dv)},
       "modes_scanned": N + 1, "domains": {}}
for name, (p, s) in DOMAINS.items():
    unstable = []
    for n in range(N + 1):
        q = (F(n) * s / p) ** 2
        tr, det = mode(q)
        if not (tr < 0 and det > 0):
            unstable.append({"n": n, "q": str(q), "trace": str(tr), "det": str(det)})
    out["domains"][name] = {"L_over_pi": f"{p}/{s}", "all_modes_linearly_stable": not unstable, "non_stable_modes": unstable}

text = json.dumps(out, indent=2, sort_keys=True)
open("results.json", "w").write(text + "\n")
print("results.json sha256", hashlib.sha256((text + "\n").encode()).hexdigest())
for name, r in out["domains"].items():
    print(f"L = {name:6s}: all modes stable = {r['all_modes_linearly_stable']}  non-stable n = {[m['n'] for m in r['non_stable_modes']]}")
