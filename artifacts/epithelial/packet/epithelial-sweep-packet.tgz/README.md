Epithelial gap-closure J-scaling sweep (Morpheus v2.3.9, CPU only)

WHAT IT TESTS
  A rule derived from the CPM energy, not fitted:
      Phi = lambda_V * A_gap^2 / (N_cells * J_cell_medium * P_gap),  P_gap = 2*sqrt(pi*A_gap)
  Phi is linear in lambda_V and inverse in J, so the closure threshold lambda_V* must be
  proportional to J. That has been verified LOCALLY at exactly one doubling: with gap k=4,
  the threshold bracket is (0.3, 1.0) at J=140 and (1, 2) at J=280. This sweep tests the
  same proportionality across two decades of J at two gap sizes with three seeds.

ACCEPTANCE (declared before the run; do not adjust it to fit the outcome)
  For each (k, seed), find the bracket: the largest lambda_V that CLOSED and the smallest
  that ARRESTED, and take lambda* as their geometric mean. The rule PASSES if lambda*/J is
  constant within a factor of 2 across J = 35..560 at each k, and FAILS otherwise.
  An arm where no bracket exists inside the swept lambda_V range is reported as
  NO-BRACKET, never silently dropped and never used to fit.

MEASUREMENT
  gap_nodes(t) = 40000 - sum(cell.volume) over living cells, read from logger.csv.
  CLOSED means gap_nodes reaches 0 before the stop time; otherwise ARRESTED.
  Closure is counted in Monte-Carlo sweeps, not model time: halving MCSDuration halves the
  model time to closure and leaves the sweep count unchanged (measured locally, 240 both ways).

CONTROLS CARRIED IN THE SWEEP
  Every (k, J) column includes lambda_V values on both sides of the predicted threshold, so
  a column that closes everywhere or arrests everywhere is visible rather than inferred.
  Three seeds per cell of the grid. Seeds share one model: their spread is descriptive, not
  an empirical uncertainty.
  Known floor, measured locally and NOT a mechanism: with both drives off the k=4 gap still
  reduces by 22.0 percent, because 61 surviving cells at a 625-node target claim 38125 of
  40000 nodes. Any closed fraction at k=4 must be read against that floor.

COST AND CAPS
  240 arms, single-thread CPU each, no GPU, no network after the binary fetch.
  Locally comparable arms took 6 to 31 s; budget 600 s per arm as a hard timeout.
  Run each arm under a cap: MemoryMax=2G MemorySwapMax=0 TasksMax=256 RuntimeMaxSec=600.
  MemoryMax alone does not bound anything on a host with swap; keep MemorySwapMax=0.
  Peak RSS measured locally: 160 MB per arm.
  Output: one logger.csv per arm, a few hundred KB each; the result tarball is a few MB.
  TIFF frames are deleted by the runner; this sweep needs no movies.

WHAT IS NOT CLAIMED
  Nothing here is calibrated to a cell line, a species or a measured tissue. CPM energies
  are model units from the upstream Act-model example. This is not a reproduction of any
  published model; see docs/epithelial-repair-card.md section 1.

PROVENANCE
  Model XMLs in models/ were built as 12 named, exactly-once edits on the pinned upstream
  Examples/CPM/Protrusion_2D.xml at tag v2.3.9, base sha256
  da2a27c8e552041ee4a51d7ff1e7332466f5180762642c997594731c92737db2.
  Each arm's parameters are in arms.json. Verify models/ against SHA256SUMS before running.
