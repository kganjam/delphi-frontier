#!/usr/bin/env bash
# Self-contained bounded Morpheus sweep. No git, no private access, CPU only, 1 thread per arm.
# Usage: bash run_packet.sh [OUTDIR] [PARALLEL]    Needs: curl, sha256sum, tar.
set -u
HERE=$(cd "$(dirname "$0")" && pwd); OUT=${1:-$HERE/out}; PAR=${2:-4}; mkdir -p "$OUT"
URL=https://gitlab.com/morpheus.lab/morpheus/-/package_files/178666119/download
BIN_SHA=3d9a6e5a4cb86824b745500df1474596d39cce5deed24f767c0841df0f94d5ad
BIN=$OUT/morpheus-2.3.9
[ -x "$BIN" ] || { curl -sL -m 600 -o "$BIN" "$URL" && chmod +x "$BIN"; }
[ "$(sha256sum "$BIN" | cut -d' ' -f1)" = "$BIN_SHA" ] || { echo "binary sha256 mismatch; refusing"; exit 3; }
(cd "$HERE" && sha256sum -c SHA256SUMS) || { echo "packet files do not match SHA256SUMS; refusing"; exit 3; }
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
run_one() {
  a=$1; mkdir -p "$OUT/$a"; cp "$HERE/models/$a.xml" "$OUT/$a/model.xml"
  ( cd "$OUT/$a" && timeout --kill-after=30 "${ARM_TIMEOUT_S:-600}" "$BIN" -f model.xml --no-gnuplot \
      --num-threads 1 > stdout.log 2>&1; echo "exit=$?" > exit.txt
    # keep only the small logger; drop frames and logs that are not needed for the threshold
    rm -f ./*.tif ./*.tiff model_graph.dot )
}
export -f run_one; export OUT HERE
ls "$HERE/models" | sed 's/\.xml$//' | xargs -P "$PAR" -I{} bash -c 'run_one {}'
for a in $(ls "$HERE/models" | sed 's/\.xml$//'); do
  echo "$a $(cat "$OUT/$a/exit.txt" 2>/dev/null) rows=$(wc -l < "$OUT/$a/logger.csv" 2>/dev/null || echo 0)"
done | tee "$OUT/result.txt"
(cd "$OUT" && tar czf ../epithelial-sweep-result.tgz --exclude=morpheus-2.3.9 .)
sha256sum "$OUT/../epithelial-sweep-result.tgz"
